<?php
include 'db_connect.php';

$result = $conn->query("SELECT queue_number, customer_name, total, status FROM orders WHERE status='pending' ORDER BY queue_number ASC");

echo "<h2>Current Queue</h2>";
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>Queue No.</th><th>Customer</th><th>Total</th><th>Status</th><th>Action</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>#{$row['queue_number']}</td>
            <td>{$row['customer_name']}</td>
            <td>{$row['total']}</td>
            <td>{$row['status']}</td>
            <td><a href='serve.php?queue={$row['queue_number']}'>Mark as Served</a></td>
          </tr>";
}
echo "</table>";

$conn->close();
?>
