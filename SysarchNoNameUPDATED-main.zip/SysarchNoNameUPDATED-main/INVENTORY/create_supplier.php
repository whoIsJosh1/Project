<?php
require 'db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit();
}

// Get POST data
$supplier_id = intval($_POST['supplier_id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$contact_person = trim($_POST['contact_person'] ?? '');
$email = trim($_POST['email'] ?? '');

// Name is always required
if (!$name) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Supplier name is required']);
    exit();
}

if ($supplier_id > 0) {
    // UPDATE existing supplier
    $stmt = $conn->prepare("UPDATE suppliers SET name = ?, contact_person = ?, email = ? WHERE supplier_id = ?");
    $stmt->bind_param("sssi", $name, $contact_person, $email, $supplier_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    $stmt->close();
} else {
    // CREATE new supplier
    $stmt = $conn->prepare("INSERT INTO suppliers (name, contact_person, email) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $contact_person, $email);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'supplier_id' => $stmt->insert_id,
            'name' => $name,
            'contact_person' => $contact_person,
            'email' => $email
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    $stmt->close();
}

$conn->close();
?>
