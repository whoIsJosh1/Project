<?php
include 'db_connect.php';
header('Content-Type: application/json');

$result = $conn->query("SELECT supplier_id, name, contact_person, email FROM suppliers");
$suppliers = [];
while ($row = $result->fetch_assoc()) {
    $suppliers[] = $row;
}
echo json_encode($suppliers);
