<?php
require 'db_connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'] ?? 0;
    $user_id = $_SESSION['user_id'];
    $quantity = $_POST['quantity'] ?? 0;
    $total = $_POST['total'] ?? 0;

    if ($product_id <= 0 || $quantity <= 0 || $total <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid sale data']);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO sales (product_id, user_id, quantity, total) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiid", $product_id, $user_id, $quantity, $total);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => $stmt->error]);
    }
    $stmt->close();
}
$conn->close();
?>