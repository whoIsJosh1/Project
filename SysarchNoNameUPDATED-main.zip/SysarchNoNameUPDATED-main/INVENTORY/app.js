// app.js - Inventory Management System with Backend Integration

const $ = (id) => document.getElementById(id);

let products = [];
let suppliers = [];
let sales = [];
let currentUser  = null;
let currentView = "products";

// --- UTILITY FUNCTIONS ---

function showNotification(message, duration = 3000) {
  const notif = document.getElementById("notification");
  if (!notif) return;

  notif.textContent = message;
  notif.classList.add("show");

  // Remove after duration
  setTimeout(() => {
    notif.classList.remove("show");
  }, duration);
}



function escapeHtml(text) {
  if (text === null || text === undefined) return "";
  return String(text).replace(/[&<>"']/g, (m) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[m]));
}

function openModal(id) {
  $(id)?.classList.add("active");
  // Focus first input for accessibility
  const modal = $(id);
  if (modal) {
    const firstInput = modal.querySelector("input, select, textarea, button");
    firstInput?.focus();
  }
}

function closeModal(id) {
  $(id)?.classList.remove("active");
}

function toggleAddButton(show) {
  const btn = $("add-button");
  if (!btn) return;
  btn.style.display = show ? "inline-block" : "none";
}

// --- SESSION CHECK & INITIAL DATA FETCH ---

async function fetchAllData() {
  await Promise.all([fetchProducts(), fetchSuppliers(), fetchSales()]);
  renderDashboard();
}

async function initApp() {
  await Promise.all([
    fetchProducts(),
    fetchSuppliers(),
    fetchSales()
  ]);
  renderDashboard(); // now it has the latest data
}


// --- FETCH DATA ---

async function fetchProducts() {
  try {
    const res = await fetch("read_product.php");
    if (!res.ok) throw new Error("Failed to fetch products");

    products = await res.json();

    // Auto-render current view if it’s products or dashboard
    if (currentView === "products") renderProducts();
    if (currentView === "dashboard") renderDashboard();

    return products;
  } catch (err) {
    console.error("Failed to fetch products:", err);
    showNotification("Failed to load products: " + err.message, "error");
    return [];
  }
}


async function fetchSuppliers() {
  try {
    const res = await fetch("get_supplier.php");
    const result = await res.json();

    if (!result.success) throw new Error(result.error || "Failed to fetch suppliers");

    suppliers = result.data; // update global array

    // Auto-render if we are in suppliers view
    if (currentView === "suppliers") renderSuppliers();

    // Update dashboard cards if on dashboard
    if (currentView === "dashboard") renderDashboard();

    // Update dropdowns (for products)
    populateSupplierDropdown();

    return suppliers;
  } catch (err) {
    showNotification("Failed to load suppliers: " + err.message, "error");
    return [];
  }
}



// Populate dropdown function
function populateSupplierDropdown() {
  const select = $("product-supplier");
  if (!select) return;
  select.innerHTML = `<option value="">No Supplier</option>` + 
    suppliers.map(s => `<option value="${s.supplier_id}">${escapeHtml(s.name)}</option>`).join("");
}


async function fetchSales() {
  try {
    const res = await fetch("read_sales.php");
    if (!res.ok) throw new Error("Failed to fetch sales");
    sales = await res.json();
    if (currentView === "sales") renderSales();
  } catch (err) {
    showNotification(err.message, "error");
  }
}


document.addEventListener("DOMContentLoaded", () => {

  // --- TOGGLE LOGIN / REGISTER ---
  const showRegister = $("show-register");
  const showLogin = $("show-login");
  const loginPage = $("login-page");
  const registerPage = $("register-page");

  showRegister?.addEventListener("click", e => {
    e.preventDefault();
    loginPage?.classList.add("hidden");
    registerPage?.classList.remove("hidden");
  });

  showLogin?.addEventListener("click", e => {
    e.preventDefault();
    registerPage?.classList.add("hidden");
    loginPage?.classList.remove("hidden");
  });

  // --- LOGIN FORM ---
 // Helper selector function (if not defined yet)
const $ = sel => document.querySelector(sel);

// --- LOGIN FORM ---
$("login-form")?.addEventListener("submit", async e => {
  e.preventDefault();

  const username = $("#login-username")?.value.trim();
  const password = $("#login-password")?.value.trim();

  // 🔒 Strong validation rules
  const usernamePattern = /^[a-zA-Z0-9_]{4,}$/; // at least 4 chars, letters/numbers only
  const passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/; // strong password

  // --- Validation checks ---
  if (!username || !password) {
    showNotification("Please fill in all fields.", "error");
    return;
  }

  if (!usernamePattern.test(username)) {
    showNotification("Username must be at least 4 characters and contain only letters/numbers.", "error");
    return;
  }

  if (!passwordPattern.test(password)) {
    showNotification(
      "Password must be 8–16 chars, include uppercase, number, and special character.",
      "error"
    );
    return;
  }

  // --- Proceed only if validation passes ---
  const formData = new FormData($("login-form"));
  try {
    const res = await fetch("login.php", { method: "POST", body: formData });
    const result = await res.json();

    if (res.ok && result.success) {
      showNotification("Login successful!", "success");
      setTimeout(() => (window.location.href = "index.html"), 1000);
    } else {
      showNotification(result.error || "Invalid username or password", "error");
    }
  } catch (err) {
    showNotification("Server error: " + err.message, "error");
  }
});


  // --- REGISTER FORM ---
  $("register-form")?.addEventListener("submit", async e => {
    e.preventDefault();
    const formData = new FormData($("register-form"));
    try {
      const res = await fetch("register.php", { method: "POST", body: formData });
      const result = await res.json();
      if (res.ok && result.success) {
        showNotification("Registered successfully! Please login.", "success");
        registerPage?.classList.add("hidden");
        loginPage?.classList.remove("hidden");
      } else {
        showNotification(result.error || "Registration failed", "error");
      }
    } catch (err) {
      showNotification("Server error: " + err.message, "error");
    }
  });

  // --- CHECK SESSION ON INDEX ---
  if ($("app")) {  // only run on main app page
    checkSession();
  }

});

// --- NOTIFICATION ---
function showNotification(msg, type="info") {
  const notif = $("notification");
  if (!notif) return;
  notif.textContent = msg;
  notif.className = `notification show ${type}`;
  setTimeout(() => notif.classList.remove("show"), 3000);
}

// --- SESSION CHECK ---
async function checkSession() {
  try {
    const res = await fetch("check_session.php");
    if (!res.ok) throw new Error("Not logged in");
    currentUser = await res.json();
    $("app")?.classList.remove("hidden"); // show main app
    // fetchAllData(); // load your dashboard/products/suppliers/sales here
    renderDashboard(); // or whatever your default view is
  } catch (err) {
    console.error(err);
    window.location.href = "login.html";
  }
}

// --- DUMMY DASHBOARD RENDER ---





// --- RENDER VIEWS ---

function renderDashboard() {
  currentView = "dashboard";
  toggleAddButton(false);
  $("page-title").textContent = "Dashboard";

  const totalRevenue = sales.reduce((sum, s) => sum + parseFloat(s.total || 0), 0).toFixed(2);
  const activeProducts = products.filter(p => p.stock > 0).length;
  const inactiveProducts = products.length - activeProducts;

  // Prepare monthly data for sparkline charts
  const months = [...Array(12).keys()].map(m => new Date(0, m).toLocaleString("default", { month: "short" }));
  const salesByMonth = Array(12).fill(0);
  sales.forEach(s => {
    const d = new Date(s.sale_date);
    salesByMonth[d.getMonth()] += 1;
  });

  

  const activeInactiveData = [activeProducts, inactiveProducts];

  $("page-content").innerHTML = `
    <div class="dashboard-grid">
      <div class="card card-primary">
        <div class="card-content">
          <h3>Total Products</h3>
          <p>${products.length}</p>
          <canvas id="productsChart" height="40"></canvas>
        </div>
        <div class="card-icon">📦</div>
      </div>
      <div class="card card-secondary">
        <div class="card-content">
          <h3>Active Products</h3>
          <p>${activeProducts}</p>
          <canvas id="activeChart" height="40"></canvas>
        </div>
        <div class="card-icon">✅</div>
      </div>
      <div class="card card-accent">
        <div class="card-content">
          <h3>Total Sales</h3>
          <p>${sales.length}</p>
          <canvas id="salesChart" height="40"></canvas>
        </div>
        <div class="card-icon">💰</div>
      </div>
      <div class="card card-revenue">
        <div class="card-content">
          <h3>Total Revenue</h3>
          <p>₱${totalRevenue}</p>
          <canvas id="revenueChart" height="40"></canvas>
        </div>
        <div class="card-icon">📈</div>
      </div>
    </div>
  `;

  // --- Mini Charts with Chart.js ---
  if (window.productsChartInstance) window.productsChartInstance.destroy();
  if (window.activeChartInstance) window.activeChartInstance.destroy();
  if (window.salesChartInstance) window.salesChartInstance.destroy();
  if (window.revenueChartInstance) window.revenueChartInstance.destroy();

  // Active vs Inactive Products (Pie)
  const ctxProducts = document.getElementById("productsChart").getContext("2d");
  window.productsChartInstance = new Chart(ctxProducts, {
    type: 'doughnut',
    data: {
      labels: ["Active", "Inactive"],
      datasets: [{
        data: activeInactiveData,
        backgroundColor: ["#5cb85c", "#d9534f"]
      }]
    },
    options: { 
      responsive: true, 
      plugins: { legend: { display: false } }, 
      cutout: '70%'
    }
  });

  // Active Products Mini Line Chart (for trend over months)
  const ctxActive = document.getElementById("activeChart").getContext("2d");
  window.activeChartInstance = new Chart(ctxActive, {
    type: 'line',
    data: {
      labels: months,
      datasets: [{ 
        label: "Active Trend", 
        data: Array(12).fill(activeProducts), // simple placeholder trend
        borderColor: "#0275d8", 
        backgroundColor: "#0275d833", 
        fill: true, 
        tension: 0.3
      }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { display: false } } }
  });

  // Sales mini line chart
  const ctxSales = document.getElementById("salesChart").getContext("2d");
  window.salesChartInstance = new Chart(ctxSales, {
    type: 'line',
    data: {
      labels: months,
      datasets: [{ label: "Monthly Sales", data: salesByMonth, borderColor: "#f0ad4e", backgroundColor: "#f0ad4e33", fill: true, tension: 0.3 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { display: false } } }
  });

  // Revenue mini line chart (optional trend)
  const revenueByMonth = Array(12).fill(0);
  sales.forEach(s => {
    const d = new Date(s.sale_date);
    revenueByMonth[d.getMonth()] += parseFloat(s.total || 0);
  });

  const ctxRevenue = document.getElementById("revenueChart").getContext("2d");
  window.revenueChartInstance = new Chart(ctxRevenue, {
    type: 'line',
    data: {
      labels: months,
      datasets: [{ label: "Revenue", data: revenueByMonth, borderColor: "#d9534f", backgroundColor: "#d9534f33", fill: true, tension: 0.3 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { x: { display: false }, y: { display: false } } }
  });

}




function renderProducts() {
  currentView = "products";
  toggleAddButton(true);
  $("page-title").textContent = "Products";

  const totalStock = products.reduce((sum, p) => sum + (p.stock || 0), 0);

  $("page-content").innerHTML = `
    <div class="products-wrapper">
      <div class="products-header">
        <div class="header-stats">
          <div class="stat-card">
            <span class="stat-icon">📦</span>
            <div class="stat-info">
              <span class="stat-value">${products.length}</span>  
              <span class="stat-label">Total Products</span>
            </div>
          </div>
          <div class="stat-card">
            <span class="stat-icon">📊</span>
            <div class="stat-info">
              <span class="stat-value">${totalStock}</span>
              <span class="stat-label">Total Stock</span>
            </div>
          </div>
        </div>
      </div>

      <div class="products-container">
        <div class="table-wrapper">
          <table class="table table-modern">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Supplier</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${products.map((p, index) => `
                <tr style="animation-delay:${index * 0.05}s">
                  <td>${p.product_id}</td>
                  <td>${escapeHtml(p.name)}</td>
                  <td>${escapeHtml(p.category)}</td>
                  <td>
                    <span class="stock-indicator ${p.stock < p.minimum_stock_level ? 'low-stock' : ''}">
                      ${p.stock}
                    </span>
                  </td>
                  <td>₱${p.price.toFixed(2)}</td>
                  <td>${escapeHtml(p.supplier_name || "—")}</td>
                  <td class="actions">
                    <button class="btn btn-edit" onclick="openEditProductModal(${p.product_id})">✏️Edit</button>
                    <button class="btn btn-delete" onclick="deleteProduct(${p.product_id})">🗑️Delete</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        ${products.length === 0 ? `
          <div class="empty-state">
            <div class="empty-icon">📦</div>
            <h3>No Products Yet</h3>
            <p>Start by adding your first product to the inventory</p>
          </div>
        ` : ''}
      </div>
    </div>
  `;
}


async function loadProducts() {
  try {
    const res = await fetch('read_products.php');
    const data = await res.json();
    products = data.map(p => ({
      ...p,
      stock: Number(p.stock), // convert stock to number
      price: parseFloat(p.price) // convert price to number
    }));
    renderProducts();
  } catch (err) {
    showNotification("Failed to load products: " + err.message, "error");
  }
}

loadProducts();


//---------SUPPLIER-----------//
// Open Add Supplier Modal

document.addEventListener("DOMContentLoaded", () => {
  if (!$("login-form") && !$("register-form")) {
    checkSession().then(() => initApp());
  }
});


function openAddSupplierModal() {
  const form = $("form-supplier");
  form.reset();              // Clear all input fields
  $("supplier-id").value = ""; // Reset hidden ID field
  openModal("modal-add-supplier");
}

function openEditSupplierModal(supplierId) {
  const supplier = suppliers.find(s => s.supplier_id == supplierId);
  if (!supplier) return showNotification("Supplier not found", "error");

  $("supplier-id").value = supplier.supplier_id;
  $("supplier-name").value = supplier.name;
  $("supplier-contact").value = supplier.contact_person || "";
  $("supplier-email").value = supplier.email || "";

  openModal("modal-add-supplier");
}


// Supplier form submit (create or update)
$("form-supplier")?.addEventListener("submit", async (e) => {
  e.preventDefault();

  const supplierId = $("supplier-id").value;
  const data = {
    name: $("supplier-name").value.trim(),
    contact_person: $("supplier-contact").value.trim(),
    email: $("supplier-email").value.trim(),
  };
  if (supplierId) data.supplier_id = supplierId;

  try {
    const url = supplierId ? "update_supplier.php" : "create_supplier.php";
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(data),
    });
    const result = await res.json();

    if (!result.success) throw new Error(result.error || "Failed to save supplier");

    showNotification(supplierId ? "Supplier updated!" : "Supplier added!", "success");

    // 🔑 Fetch updated suppliers and re-render table/dashboard automatically
    await fetchSuppliers();
    renderSuppliers();

    $("form-supplier").reset();
    $("supplier-id").value ="";

    closeModal("modal-add-supplier");
  } catch (err) {
    showNotification(err.message, "error");
  }
});


// Delete supplier
async function deleteSupplier(supplierId) {
  if (!confirm("Are you sure you want to delete this supplier?")) return;

  try {
    const res = await fetch("delete_supplier.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ supplier_id: supplierId })
    });

    const result = await res.json();

    if (!result.success) throw new Error(result.error || "Failed to delete supplier");

    showNotification("Supplier deleted!", "success");

    // 🔑 Refresh suppliers array and re-render table
    await fetchSuppliers();
    if (currentView === "suppliers") renderSuppliers();
    if (currentView === "dashboard") renderDashboard();

  } catch (err) {
    showNotification(err.message, "error");
  }
}


function renderSuppliers() {
  currentView = "suppliers";
  toggleAddButton(true);
  $("page-title").textContent = "Suppliers";

  const tableBody = $("page-content");
  if (!tableBody) return;

  if (!suppliers.length) {
    tableBody.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📦</div>
        <h3>No suppliers found</h3>
        <p>Start adding suppliers to manage your inventory efficiently.</p>
      </div>
    `;
    return;
  }

  tableBody.innerHTML = `
    <div class="suppliers-container">
      <table class="table-modern">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Contact Person</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${suppliers.map(s => `
            <tr>
              <td><span class="id-badge">${s.supplier_id}</span></td>
              <td class="supplier-name">${escapeHtml(s.name)}</td>
              <td>${escapeHtml(s.contact_person)}</td>
              <td>${escapeHtml(s.email)}</td>
              <td class="actions">
                <button class="btn-edit" onclick="openEditSupplierModal(${s.supplier_id})">Edit</button>
                <button class="btn-delete" onclick="deleteSupplier(${s.supplier_id})">Delete</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}



function renderSales() {
  currentView = "sales";
  toggleAddButton(false);
  $("page-title").textContent = "Sales";

  const tableBody = $("page-content");
  if (!tableBody) return;

  if (!sales.length) {
    tableBody.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">💰</div>
        <h3>No sales found</h3>
        <p>Sales records will appear here once transactions are made.</p>
      </div>
    `;
    return;
  }

  tableBody.innerHTML = `
    <div class="sales-container">
      <table class="table-modern">
        <thead>
          <tr>
            <th>ID</th>
            <th>Products</th>
            <th>Total Qty</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${sales.map(s => {
            const productsList = s.items.map(item => `${escapeHtml(item.product_name)} (x${item.quantity})`).join("<br>");
            const totalQty = s.items.reduce((sum, item) => sum + item.quantity, 0);
            return `
              <tr>
                <td data-label="ID"><span class="id-badge">${s.sale_id}</span></td>
                <td data-label="Products">${productsList}</td>
                <td data-label="Total Qty">${totalQty}</td>
                <td data-label="Total" class="price-tag">₱${parseFloat(s.total).toFixed(2)}</td>
                <td data-label="Payment">${escapeHtml(s.payment_method)}</td>
                <td data-label="Date">${new Date(s.sale_date).toLocaleString()}</td>
                <td data-label="Status">
                  <span class="stock-indicator ${s.status.toLowerCase() === 'pending' ? 'low-stock' : 'completed'}">
                    ${escapeHtml(s.status)}
                  </span>
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}









// --- POPULATE SUPPLIER DROPDOWN IN PRODUCT FORM ---

function populateSupplierDropdown(selectedId = "") {
    const supplierSelect = $("product-supplier");
    if (!supplierSelect) return;

    supplierSelect.innerHTML = `<option value="">No Supplier</option>`;
    suppliers.forEach(s => {
        const option = document.createElement("option");
        option.value = s.supplier_id;
        option.textContent = s.name;
        if (s.supplier_id == selectedId) option.selected = true;
        supplierSelect.appendChild(option);
    });
}

// --- PRODUCT MODAL HANDLERS ---

function openAddProductModal() {
  $("form-product").reset();      // Clear all fields
  $("product-id").value = "";      // Reset hidden ID
  populateSupplierDropdown();      // Update supplier options
  openModal("modal-add-product");
}



function openEditProductModal(productId = null) {
    populateSupplierDropdown();

    const form = $("form-product");
    if (!form) return;

    const isEdit = productId !== null;
    let product = null;

    if (isEdit) {
        product = products.find(p => Number(p.product_id) === Number(productId));
        if (!product) return showNotification("Product not found", "error");

        $("product-id").value = product.product_id;
        $("product-name").value = product.name;
        $("product-category").value = product.category;
        $("product-price").value = product.price;
        $("product-stock").value = product.stock;
        $("min-stock").value = product.minimum_stock_level || 0;
        $("product-supplier").value = product.supplier_id || "";

        const photoPreview = $("product-photo-preview");
        if (photoPreview) photoPreview.src = product.photo || "placeholder.png";
    } else {
        form.reset();
        $("product-id").value = "";
        const photoPreview = $("product-photo-preview");
        if (photoPreview) photoPreview.src = "placeholder.png";
    }

    openModal("modal-add-product");
}


// Product form submit (create or update)
$("form-product")?.addEventListener("submit", async e => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const productId = formData.get("product_id");

    // Stock validation: mark Not Available if stock <= 0
    const stock = Number(formData.get("stock"));
    if (stock <= 0) {
        formData.append("status", "not_available");
    }

    const url = productId ? "update_product.php" : "add_product.php";

    try {
        const res = await fetch(url, { method: "POST", body: formData });
        const result = await res.json();

        if (res.ok && result.success) {
            showNotification(result.message || "Product saved!", "success");
            closeModal("modal-add-product");
            loadProducts(); // Refresh product list
        } else {
            showNotification(result.error || "Failed to save product", "error");
        }
    } catch (err) {
        showNotification("Server error: " + err.message, "error");
    }
});



// Delete product
async function deleteProduct(productId) {
  if (!confirm("Are you sure you want to delete this product?")) return;

  try {
    const res = await fetch("delete_product.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ product_id: productId })
    });

    const result = await res.json();

    if (!result.success) throw new Error(result.error || "Failed to delete product");

    showNotification("Product deleted!", "success");

    // 🔑 Refresh products array and re-render table
    await fetchProducts();
    renderProducts();
    if (currentView === "products") renderProducts();
    if (currentView === "dashboard") renderDashboard();

  } catch (err) {
    showNotification(err.message, "error");
  }
}

// --- SUPPLIER MODAL HANDLERS ---

function openAddSupplierModal() {
  $("form-supplier").reset();
  $("supplier-id").value = "";
  openModal("modal-add-supplier");
}

async function openEditSupplierModal(supplierId) {
  const supplier = suppliers.find(s => s.supplier_id === supplierId);
  if (!supplier) return showNotification("Supplier not found", "error");
  $("supplier-id").value = supplier.supplier_id;
  $("supplier-name").value = supplier.name;
  $("supplier-contact").value = supplier.contact_person || "";
  $("supplier-email").value = supplier.email || "";
  openModal("modal-add-supplier");
}
  

// --- NAVIGATION ---

document.addEventListener("DOMContentLoaded", () => {
  const navButtons = document.querySelectorAll("nav.sidebar .menu > button");

  // Create indicator for active menu
  const indicator = document.createElement("div");
  indicator.className = "indicator";
  document.querySelector("nav.sidebar .menu").appendChild(indicator);

  // Set active nav button
  function setActiveNav(button) {
    navButtons.forEach((b) => b.classList.remove("active"));
    button.classList.add("active");

    // Animate indicator
    indicator.style.top = button.offsetTop + "px";
    indicator.style.height = button.offsetHeight + "px";
  }

  // Initialize first button as active
  setActiveNav(navButtons[0]);

  // Handle click events
  navButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setActiveNav(btn);

      switch (btn.id) {
        case "nav-dashboard": renderDashboard(); break;
        case "nav-products": renderProducts(); break;
        case "nav-suppliers": renderSuppliers(); break;
        case "nav-sales": renderSales(); break;
      }
    });
  });

  // Optional: handle window resize for indicator
  window.addEventListener("resize", () => {
    const activeBtn = document.querySelector("nav.sidebar .menu > button.active");
    if (activeBtn) {
      indicator.style.top = activeBtn.offsetTop + "px";
      indicator.style.height = activeBtn.offsetHeight + "px";
    }
  });
});


  // --- ADD BUTTON ---
  $("add-button")?.addEventListener("click", () => {
    if (currentView === "products") openAddProductModal();
    else if (currentView === "suppliers") openAddSupplierModal();
  });

  // --- MODAL CLOSE ---
  document.querySelectorAll(".modal .close-btn, .modal .cancel-btn").forEach((btn) =>
    btn.addEventListener("click", () => closeModal(btn.dataset.target))
  );

  // --- SESSION CHECK ---
  if (!$("login-form") && !$("register-form")) {
    checkSession();
  }


