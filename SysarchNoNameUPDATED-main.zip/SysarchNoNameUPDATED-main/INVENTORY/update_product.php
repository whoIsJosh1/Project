<?php
error_reporting(E_ERROR | E_PARSE); // Only show errors
header('Content-Type: application/json');
require 'db_connect.php'; // Database connection

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }

    $product_id = $_POST['product_id'] ?? null;
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price = $_POST['price'] ?? 0;
    $stock = $_POST['stock'] ?? 0;
    $min_stock = $_POST['minimum_stock_level'] ?? 0;
    $supplier_id = $_POST['supplier_id'] ?: null;

    if (!$product_id || !$name || !$category || $price < 0 || $stock < 0) {
        throw new Exception("Invalid product data");
    }

    // Handle photo upload
    $photo = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            throw new Exception("Invalid file type");
        }

        $uniqueName = uniqid() . "." . $ext;
        $uploadDir = __DIR__ . "/ORDERING/"; // Save directly to ORDERING folder
        if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
        $filePath = $uploadDir . $uniqueName;

        if (!move_uploaded_file($_FILES['photo']['tmp_name'], $filePath)) {
            throw new Exception("Failed to upload image");
        }

        $photo = "ORDERING/" . $uniqueName;
    }

    // Build SQL query dynamically
    $fields = "name=?, category=?, price=?, stock=?, minimum_stock_level=?, supplier_id=?";
    $types = "ssidii";
    $params = [$name, $category, $price, $stock, $min_stock, $supplier_id];

    if ($photo) {
        $fields .= ", photo=?";
        $types .= "s";
        $params[] = $photo;
    }

    $stmt = $conn->prepare("UPDATE products SET $fields WHERE product_id=?");
    $types .= "i";
    $params[] = $product_id;

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product updated successfully']);
    } else {
        throw new Exception($stmt->error);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
