<?php
require 'db_connect.php';

// Fetch sales without user info
$sqlSales = "SELECT sale_id, total, payment_method, sale_date, status
             FROM sales
             ORDER BY sale_date DESC";

$resultSales = $conn->query($sqlSales);

$sales = [];

while ($sale = $resultSales->fetch_assoc()) {
    $sale_id = $sale['sale_id'];

    // Get items
    $sqlItems = "SELECT si.product_id, p.name AS product_name, si.quantity, si.price, si.subtotal
                 FROM sale_items si
                 JOIN products p ON si.product_id = p.product_id
                 WHERE si.sale_id = ?
                 ORDER BY si.item_id ASC";

    $stmt = $conn->prepare($sqlItems);
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $itemsResult = $stmt->get_result();

    $items = [];
    while ($item = $itemsResult->fetch_assoc()) {
        $items[] = $item;
    }

    $sale['items'] = $items;
    $sales[] = $sale;
}

header('Content-Type: application/json');
echo json_encode($sales);
?>
