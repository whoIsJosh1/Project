<?php
require 'db_connect.php';

$sql = "SELECT 
            p.product_id, 
            p.name, 
            p.category,  
            p.price, 
            p.stock, 
            p.photo, 
            p.minimum_stock_level,
            s.name AS supplier_name
        FROM products p
        LEFT JOIN suppliers s 
          ON p.supplier_id = s.supplier_id
        ORDER BY p.name ASC";

$result = $conn->query($sql);
$products = [];
while ($row = $result->fetch_assoc()) {
    $row['stock'] = (int)$row['stock']; // convert to number
    $row['price'] = (float)$row['price']; // convert to number
    $row['minimum_stock_level'] = (int)$row['minimum_stock_level']; // convert to number
    $products[] = $row;
}
header('Content-Type: application/json');
echo json_encode($products);

?>
