<?php
require 'db_connect.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get supplier ID safely
$supplier_id = intval($_POST['supplier_id'] ?? 0);

if ($supplier_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid supplier ID']);
    exit;
}

try {
    // Optionally: unlink products from supplier first to avoid foreign key issues
    $unlink = $conn->prepare("UPDATE products SET supplier_id = NULL WHERE supplier_id = ?");
    $unlink->bind_param("i", $supplier_id);
    $unlink->execute();
    $unlink->close();

    // Delete supplier
    $stmt = $conn->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Supplier not found']);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>
