<?php
header('Content-Type: application/json');
include 'db_connect.php'; // database connection

$category = isset($_GET['category']) ? $_GET['category'] : '';

$query = "SELECT product_id, name, category, price, stock, photo 
          FROM products 
          WHERE status='active'";

if ($category !== '') {
    $query .= " AND category = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $category);
} else {
    $stmt = $conn->prepare($query);
}

$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    // Use default image if none uploaded
    $row['photo'] = !empty($row['photo']) ? $row['photo'] : 'ORDERING/default.jpg';
    $products[] = $row;
}

echo json_encode(['success' => true, 'products' => $products]);
?>
