<?php
header('Content-Type: application/json');
require 'db_connect.php';

// Kunin lahat ng sales kasama ang items
$sql = "
SELECT s.sale_id, s.user_id, s.total, s.payment_method, s.sale_date, s.status,
       si.item_id, si.product_id, si.quantity, si.price AS item_price, si.subtotal,
       p.name AS product_name
FROM sales s
LEFT JOIN sale_items si ON s.sale_id = si.sale_id
LEFT JOIN products p ON si.product_id = p.product_id
ORDER BY s.sale_date DESC, s.sale_id DESC
";

$result = $conn->query($sql);

$sales = [];
while ($row = $result->fetch_assoc()) {
    $sale_id = $row['sale_id'];

    if (!isset($sales[$sale_id])) {
        $sales[$sale_id] = [
            'sale_id' => $sale_id,
            'user_id' => $row['user_id'],
            'total' => $row['total'],
            'payment_method' => $row['payment_method'],
            'sale_date' => $row['sale_date'],
            'status' => $row['status'],
            'items' => []
        ];
    }

    if ($row['item_id']) {
        $sales[$sale_id]['items'][] = [
            'item_id' => $row['item_id'],
            'product_id' => $row['product_id'],
            'product_name' => $row['product_name'],
            'quantity' => $row['quantity'],
            'price' => $row['item_price'],
            'subtotal' => $row['subtotal']
        ];
    }
}

// Convert associative array to indexed array
$sales = array_values($sales);

echo json_encode(['success' => true, 'sales' => $sales]);
$conn->close();
?>
