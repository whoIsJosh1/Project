<?php
header('Content-Type: application/json');
include 'db_connect.php';

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

$result = $conn->query("SELECT * FROM suppliers ORDER BY supplier_id DESC");
if (!$result) {
    echo json_encode(['success' => false, 'error' => 'Query failed: ' . $conn->error]);
    exit();
}

$suppliers = [];
while ($row = $result->fetch_assoc()) {
    $suppliers[] = $row;
}

echo json_encode(['success' => true, 'data' => $suppliers]);
$conn->close();
