<?php
require 'db_connect.php';

$sql = "SELECT supplier_id, name, contact_person, email FROM suppliers ORDER BY name ASC";
$result = $conn->query($sql);

$suppliers = [];
while ($row = $result->fetch_assoc()) {
    $suppliers[] = $row;
}

header('Content-Type: application/json');
echo json_encode($suppliers);
?>